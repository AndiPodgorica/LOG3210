package analyzer;

/**
 * Created by febru on 19-02-01.
 */
public class SemantiqueError extends Error{
    public SemantiqueError(String message) {
        super(message);
    }

}
