package analyzer.visitors;

import analyzer.ast.*;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;


/**
 * Created: 19-02-15
 * Last Changed: 20-10-6
 * Author: Félix Brunet & Doriane Olewicki
 * Modified by: Gérard Akkerhuis
 *
 * Description: Ce visiteur explore l'AST et génère un code intermédiaire.
 */

public class IntermediateCodeGenFallVisitor implements ParserVisitor {

    private final PrintWriter m_writer;

    public IntermediateCodeGenFallVisitor(PrintWriter writer) {
        m_writer = writer;
    }
    public HashMap<String, VarType> SymbolTable = new HashMap<>();

    private int id = 0;
    private int label = 0;
    private final String fallthrough = "fall";

    private String genId() {
        return "_t" + id++;
    }
    private String genLabel() {
        return "_L" + label++;
    }

    @Override
    public Object visit(SimpleNode node, Object data) {
        return data;
    }

    @Override
    public Object visit(ASTProgram node, Object dataObject)  {
        dataObject = new BoolLabel();
        node.childrenAccept(this, dataObject);
        return null;
    }

    @Override
    public Object visit(ASTDeclaration node, Object data) {
        ASTIdentifier id = (ASTIdentifier) node.jjtGetChild(0);
        VarType t = node.getValue().equals("bool") ? VarType.Bool : VarType.Number;
        SymbolTable.put(id.getValue(), t);
        return null;
    }

    @Override
    public Object visit(ASTBlock node, Object data) {
        StringBuilder address = new StringBuilder();
        if (node.jjtGetNumChildren() == 0) { return address.toString();}
        if(node.jjtGetParent().getClass() == ASTProgram.class){
            ((BoolLabel)data).next = genLabel();
        }
        String label = ((BoolLabel)data).next;
        for (int i = 0; i < node.jjtGetNumChildren(); ++i) {
            BoolLabel newlabel = new BoolLabel();

            if(node.jjtGetParent().getClass() == ASTIfStmt.class){
                newlabel = new BoolLabel();
            }
            else if(node.jjtGetParent().getClass() == ASTForStmt.class){
                newlabel.lTrue = fallthrough;
            }

            if (i != node.jjtGetNumChildren() - 1 && node.jjtGetParent().getClass()!= ASTForStmt.class) {
                ((BoolLabel)data).next = genLabel();
            } else {
                ((BoolLabel)data).next = label;
            }

            newlabel.next = ((BoolLabel)data).next;
            address.append((String) node.jjtGetChild(i).jjtAccept(this, newlabel));
            if(node.jjtGetParent().getClass() !=  ASTIfStmt.class &&
                    node.jjtGetParent().getClass()!= ASTWhileStmt.class &&
                    node.jjtGetParent().getClass() != ASTForStmt.class){
                m_writer.println(((BoolLabel)data).next);
            }
            else {
                if (i < node.jjtGetNumChildren() - 1){
                    m_writer.println(((BoolLabel)data).next);
                }
            }
        }
        return address.toString();
    }

    @Override
    public Object visit(ASTStmt node, Object data) {
        node.childrenAccept(this, data);
        return null;
    }

    @Override
    public Object visit(ASTForStmt node, Object data) {
        String genLabel = genLabel();
        ((BoolLabel)data).parent = ((BoolLabel)data).next;
        ((BoolLabel) data).lFalse = genLabel;
        ((BoolLabel) data).lTrue = fallthrough;

        node.jjtGetChild(0).jjtAccept(this,data);
        m_writer.println(genLabel);
        node.jjtGetChild(1).jjtAccept(this,data);
        ((BoolLabel) data).next= genLabel;
        node.jjtGetChild(3).jjtAccept(this,data);
        node.jjtGetChild(2).jjtAccept(this,data);
        m_writer.println(String.format("goto %s", genLabel));

        return null;
    }

    @Override
    public Object visit(ASTIfStmt node, Object data) {
        ((BoolLabel)data).lTrue = fallthrough;

        if(node.jjtGetNumChildren() >= 3)
            ((BoolLabel)data).lFalse = genLabel();
        else
            ((BoolLabel)data).lFalse = ((BoolLabel)data).next;

        node.jjtGetChild(0).jjtAccept(this, data);
        node.jjtGetChild(1).jjtAccept(this, data);

        if(node.jjtGetNumChildren() >= 3 ){
            m_writer.println(String.format("goto %s", ((BoolLabel)data).next));
            m_writer.println(String.format("%s", ((BoolLabel)data).lFalse));
            node.jjtGetChild(2).jjtAccept(this, data);
        }
        return null;
    }

    @Override
    public Object visit(ASTWhileStmt node, Object data) {
        String genLabel = genLabel();
        ((BoolLabel)data).lFalse = ((BoolLabel)data).next;
        ((BoolLabel)data).lTrue = fallthrough;
        ((BoolLabel)data).next = genLabel;
        m_writer.println(genLabel);

        node.jjtGetChild(0).jjtAccept(this, data);
        node.jjtGetChild(1).jjtAccept(this, data);

        m_writer.println(String.format("goto %s", genLabel));
        return "";
    }


    @Override
    public Object visit(ASTAssignStmt node, Object data) {
        StringBuilder string = new StringBuilder();
        string.append(node.jjtGetChild(1).jjtAccept(this, data));
        String lexeme = (String) node.jjtGetChild(0).jjtAccept(this, data);
        BoolLabel boolLabel = (BoolLabel) data;

        if(!string.toString().equals("")){
            m_writer.println(lexeme + " = " + string);
            return "";
        }

        m_writer.println(lexeme + " = 1");
        m_writer.println(String.format("goto %s",boolLabel.next));

        if(boolLabel.lTrue!= null && !boolLabel.lTrue.equals(fallthrough)) {
            m_writer.println(boolLabel.lTrue);
        }
        if(boolLabel.lFalse!= null && !boolLabel.lFalse.equals(fallthrough)) {
            m_writer.println(boolLabel.lFalse);
        }

        m_writer.println(lexeme + " = 0");

        return "";
    }

    @Override
    public Object visit(ASTExpr node, Object data){
        return node.jjtGetChild(0).jjtAccept(this, data);
    }

    public String codeExtAddMul(SimpleNode node, Object data,
                                Vector<String> ops, List<String> validOps) {
        StringBuilder str = new StringBuilder();
        for(int i = 0; i < node.jjtGetNumChildren(); ++i){
            str.append(node.jjtGetChild(i).jjtAccept(this, data));
            if(ops.size() > 0 && i < ops.size() && validOps.contains(ops.get(i))){
                str.append(" ").append(ops.get(i)).append(" ");
            }
        }
        return str.toString();
    }

    public Object visit(ASTAddExpr node, Object data) {
        if(node.getOps().size() <= 0) return node.jjtGetChild(0).jjtAccept(this, data);

        StringBuilder string = new StringBuilder();
        string.append(genId());
        String newString = string.toString();

        ArrayList<String> validOps = new ArrayList<>();
        validOps.add("+");
        validOps.add("-");
        string.append(" = ");
        string.append(codeExtAddMul(node, data, node.getOps(), validOps));

        m_writer.println(string);
        return newString;
    }

    @Override
    public Object visit(ASTMulExpr node, Object data) {
        if(node.getOps().size() <= 0) return node.jjtGetChild(0).jjtAccept(this, data);
        StringBuilder string = new StringBuilder();
        string.append(genId());
        String newString = string.toString();

        ArrayList<String> validOps = new ArrayList<>();
        validOps.add("*");
        validOps.add("/");
        string.append(" = ");
        string.append(codeExtAddMul(node, data, node.getOps(), validOps));

        m_writer.println(string);
        return newString;
    }
    
    @Override
    public Object visit(ASTUnaExpr node, Object data) {
        if(node.getOps().size() <= 0) return node.jjtGetChild(0).jjtAccept(this, data);
        String oldVal = "";
        for(int i = 0; i< node.getOps().size(); i++){
            String addrChild = i<node.jjtGetNumChildren() ? (String)node.jjtGetChild(0).jjtAccept(this, data) : String.format("%s",oldVal) ;
            
            String id = genId();
            StringBuilder addr = new StringBuilder();
            m_writer.println(addr.append(id)
                    .append(String.format(" = %s ", node.getOps().get(i)))
                    .append(addrChild));
            oldVal = id;
        }
        return oldVal;
    }
    
    @Override
    public Object visit(ASTBoolExpr node, Object data) {
        if(node.getOps().size() <= 0)  return node.jjtGetChild(0).jjtAccept(this, data);

        if(node.jjtGetParent().getClass() != ASTBoolExpr.class
                && ((BoolLabel)data).lTrue == null) {
            ((BoolLabel) data).lTrue = fallthrough;
            ((BoolLabel) data).lFalse = genLabel();
        }

        if(node.getOps().get(0).equals("&&")){
            BoolLabel firstData = new BoolLabel();
            firstData.lTrue= fallthrough;
            if(((BoolLabel)data).lFalse.equals(fallthrough)){
                firstData.lFalse = genLabel();
            }
            else{
                firstData.lFalse = ((BoolLabel) data).lFalse;
            }
            BoolLabel secondData = new BoolLabel();
            secondData.lTrue = ((BoolLabel) data).lTrue;
            secondData.lFalse = ((BoolLabel) data).lFalse;
            node.jjtGetChild(0).jjtAccept(this, firstData);
            node.jjtGetChild(1).jjtAccept(this, secondData);
            if(((BoolLabel) data).lFalse.equals(fallthrough)){
                m_writer.println(firstData.lFalse);
            }
        }
        else{
            BoolLabel firstData = new BoolLabel();
            if(((BoolLabel)data).lTrue.equals(fallthrough)){
                firstData.lTrue = genLabel();
            }
            else{
                firstData.lTrue = ((BoolLabel)data).lTrue;
            }
            firstData.lFalse = fallthrough;
            BoolLabel secondData = new BoolLabel();
            secondData.lTrue = ((BoolLabel) data).lTrue;
            secondData.lFalse = ((BoolLabel)data).lFalse;
            node.jjtGetChild(0).jjtAccept(this, firstData);
            node.jjtGetChild(1).jjtAccept(this,secondData);
            if(((BoolLabel) data).lTrue.equals(fallthrough)){
                m_writer.println(firstData.lTrue);
            }
        }
        return "";
    }

    @Override
    public Object visit(ASTCompExpr node, Object data) {
        if(node.getValue() != null){
            if(((BoolLabel)data).lTrue == null) {
                ((BoolLabel) data).lTrue = fallthrough;
                ((BoolLabel) data).lFalse = genLabel();
            }
            if(((BoolLabel)data).lFalse == null){
                ((BoolLabel) data).lFalse = genLabel();
            }
            if(((BoolLabel) data).parent == null) {
                if (!((BoolLabel) data).lTrue.equals(fallthrough) && !((BoolLabel) data).lFalse.equals(fallthrough)) {
                    String firstReturn = (String) node.jjtGetChild(0).jjtAccept(this, data);
                    String secondReturn = (String) node.jjtGetChild(1).jjtAccept(this, data);
                    m_writer.println(String.format("if %s %s %s goto %s", firstReturn,
                            node.getValue(), secondReturn, ((BoolLabel) data).lTrue));
                    if(((BoolLabel) data).parent == null) {
                        m_writer.println(String.format("goto %s", ((BoolLabel) data).lFalse));
                    }
                } else if (!((BoolLabel) data).lTrue.equals(fallthrough) && ((BoolLabel) data).lFalse.equals(fallthrough)) {
                    String ret1 = (String) node.jjtGetChild(0).jjtAccept(this, data);
                    String ret2 = (String) node.jjtGetChild(1).jjtAccept(this, data);
                    m_writer.println(String.format("if %s %s %s goto %s", ret1,
                            node.getValue(), ret2, ((BoolLabel) data).lTrue));
                } else if (((BoolLabel) data).lTrue.equals(fallthrough) && !((BoolLabel) data).lFalse.equals(fallthrough)) {
                    String ret1 = (String) node.jjtGetChild(0).jjtAccept(this, data);
                    String ret2 = (String) node.jjtGetChild(1).jjtAccept(this, data);
                    m_writer.println(String.format("ifFalse %s %s %s goto %s", ret1,
                            node.getValue(), ret2, ((BoolLabel) data).lFalse));
                } else {
                    throw new Error();
                }
            }
            else{
                if (!((BoolLabel) data).lTrue.equals(fallthrough) && !((BoolLabel) data).lFalse.equals(fallthrough)) {
                    String ret1 = (String) node.jjtGetChild(0).jjtAccept(this, data);
                    String ret2 = (String) node.jjtGetChild(1).jjtAccept(this, data);
                    m_writer.println(String.format("if %s %s %s goto %s", ret1,
                            node.getValue(), ret2, ((BoolLabel) data).parent));
                    m_writer.println(String.format("goto %s", ((BoolLabel) data).lFalse));
                } else if (!((BoolLabel) data).lTrue.equals(fallthrough) && ((BoolLabel) data).lFalse.equals(fallthrough)) {
                    String ret1 = (String) node.jjtGetChild(0).jjtAccept(this, data);
                    String ret2 = (String) node.jjtGetChild(1).jjtAccept(this, data);
                    m_writer.println(String.format("if %s %s %s goto %s", ret1,
                            node.getValue(), ret2, ((BoolLabel) data).parent));
                } else if (((BoolLabel) data).lTrue.equals(fallthrough) && !((BoolLabel) data).lFalse.equals(fallthrough)) {
                    String ret1 = (String) node.jjtGetChild(0).jjtAccept(this, data);
                    String ret2 = (String) node.jjtGetChild(1).jjtAccept(this, data);
                    m_writer.println(String.format("ifFalse %s %s %s goto %s", ret1,
                            node.getValue(), ret2, ((BoolLabel) data).parent));
                } else {
                    throw new Error();
                }
            }
            return "";
        }else{
            return node.jjtGetChild(0).jjtAccept(this, data);
        }
    }

    @Override
    public Object visit(ASTNotExpr node, Object data) {
        if(node.getOps().size() <= 0) return node.jjtGetChild(0).jjtAccept(this, data);

        if(((BoolLabel)data).lTrue == null){
            ((BoolLabel) data).lTrue = fallthrough;
            ((BoolLabel) data).lFalse = genLabel();
        }

        BoolLabel dataForm = (BoolLabel)data;
        BoolLabel interData = new BoolLabel(dataForm.lTrue, dataForm.lFalse);
        BoolLabel newData = new BoolLabel();
        for(int i = 0; i< node.getOps().size(); i++){
            newData.lTrue = interData.lFalse;
            newData.lFalse = interData.lTrue;
            interData = new BoolLabel(newData.lTrue, newData.lFalse);
        }
        node.jjtGetChild(0).jjtAccept(this, newData);
        return "";
    }

    @Override
    public Object visit(ASTGenValue node, Object data) {
        return node.jjtGetChild(0).jjtAccept(this, data);
    }

    @Override
    public Object visit(ASTBoolValue node, Object data) {
        if(node.getValue()){
            if(((BoolLabel)data).lTrue== null)
                ((BoolLabel)data).lTrue = genLabel();
            else if (!((BoolLabel) data).lTrue.equals(fallthrough))
                m_writer.println(String.format("goto %s", ((BoolLabel) data).lTrue));
        }
        else {
            if(((BoolLabel)data).lFalse == null)
                ((BoolLabel)data).lFalse = genLabel();

            if(!((BoolLabel)data).lFalse.equals(fallthrough))
                m_writer.println(String.format("goto %s", ((BoolLabel) data).lFalse));
        }

        return "";
    }


    @Override
    public Object visit(ASTIdentifier node, Object data) {
        if(node.jjtGetParent().getClass() == ASTAssignStmt.class
                || SymbolTable.get(node.getValue()) != VarType.Bool)
            return node.getValue();

        BoolLabel dataForm = (BoolLabel)data;
        if(((BoolLabel)data).lTrue == null)
            dataForm.lTrue = genLabel();
        if(((BoolLabel) data).lFalse== null){
            m_writer.println(String.format("ifFalse %s == 1 goto %s", node.getValue(),
                dataForm.lTrue));
            return "";
        }

        if (!((BoolLabel) data).lTrue.equals(fallthrough) && !((BoolLabel) data).lFalse.equals(fallthrough)) {
            m_writer.println(String.format("ifFalse %s == 1 goto %s", node.getValue(),
                    dataForm.lTrue));
            m_writer.println(((BoolLabel) data).lFalse);
        } else if (!((BoolLabel) data).lTrue.equals(fallthrough) && ((BoolLabel) data).lFalse.equals(fallthrough)) {
            m_writer.println(String.format("if %s == 1 goto %s", node.getValue(),
                    dataForm.lTrue));
        } else if (((BoolLabel) data).lTrue.equals(fallthrough) && !((BoolLabel) data).lFalse.equals(fallthrough)) {
            m_writer.println(String.format("ifFalse %s == 1 goto %s", node.getValue(),
                    dataForm.lFalse));
        } else {
            throw new Error();
        }

        return "";
    }

    @Override
    public Object visit(ASTIntValue node, Object data) {
        return Integer.toString(node.getValue());
    }

    @Override
    public Object visit(ASTSwitchStmt node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, data);
        }
        return null;
    }

    @Override
    public Object visit(ASTCaseStmt node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, data);
        }
        return null;
    }

    @Override
    public Object visit(ASTDefaultStmt node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, data);
        }
        return null;
    }

    public enum VarType {
        Bool,
        Number
    }

    private static class BoolLabel {
        public String lTrue = null;
        public String lFalse = null;
        public String parent;
        public String next;

        public BoolLabel(String t, String f) {
            lTrue = t;
            lFalse = f;
        }
        public BoolLabel(){
        }
    }
}
