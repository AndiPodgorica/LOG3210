package analyzer.visitors;

import analyzer.ast.*;
import com.sun.org.apache.xpath.internal.operations.Bool;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;
import sun.awt.Symbol;

import java.awt.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;


/**
 * Created: 19-02-15
 * Last Changed: 20-10-6
 * Author: Félix Brunet & Doriane Olewicki
 * Modified by: Gérard Akkerhuis
 *
 * Description: Ce visiteur explore l'AST et génère un code intermédiaire.
 */

public class IntermediateCodeGenVisitor implements ParserVisitor {
    private final PrintWriter m_writer;

    public IntermediateCodeGenVisitor(PrintWriter writer) {
        m_writer = writer;
    }
    public HashMap<String, VarType> SymbolTable = new HashMap<>();

    private int id = 0;
    private int label = 0;

    private String genId() {
        return "_t" + id++;
    }
    private String genLabel() {
        return "_L" + label++;
    }

    @Override
    public Object visit(SimpleNode node, Object data) {
        return data;
    }

    @Override
    public Object visit(ASTProgram node, Object data)  {
        data = new BoolLabel();
        node.childrenAccept(this, data);
        return null;
    }

    @Override
    public Object visit(ASTDeclaration node, Object data) {
        ASTIdentifier id = (ASTIdentifier) node.jjtGetChild(0);
        VarType t;
        if(node.getValue().equals("bool")) {
            t = VarType.Bool;
        } else {
            t = VarType.Number;
        }
        SymbolTable.put(id.getValue(), t);
        return null;
    }

    @Override
    public Object visit(ASTBlock node, Object data) {
        StringBuilder address = new StringBuilder();
        if (node.jjtGetNumChildren() == 0) return address.toString();
        if(node.jjtGetParent().getClass() == ASTProgram.class){
            ((BoolLabel)data).next = genLabel();
        }
        String firstLabel = ((BoolLabel)data).next;
        for (int i = 0; i < node.jjtGetNumChildren(); ++i) {
            BoolLabel newData = new BoolLabel();
            ((BoolLabel)data).next = (i == node.jjtGetNumChildren() - 1) ? firstLabel : genLabel();
            if(node.jjtGetParent().getClass() == ASTIfStmt.class){
                newData = new BoolLabel();
            }
            newData.next = ((BoolLabel)data).next;
            if(node.jjtGetParent().getClass() == ASTForStmt.class){
                newData.lTrue = ((BoolLabel) data).lFalse;
            }
            address.append((String) node.jjtGetChild(i).jjtAccept(this, newData));
            if(node.jjtGetParent().getClass() !=  ASTIfStmt.class
                    && node.jjtGetParent().getClass() != ASTWhileStmt.class
                    && node.jjtGetParent().getClass() != ASTForStmt.class){
                m_writer.println(((BoolLabel)data).next);
            }
            else {
                if (i < node.jjtGetNumChildren() - 1){
                    m_writer.println(((BoolLabel)data).next);
                }
            }
        }
        return address.toString();
    }

    @Override
    public Object visit(ASTStmt node, Object data) {
        node.childrenAccept(this, data);
        return null;
    }

    public Object visit(ASTForStmt node, Object data) {
        String first = genLabel();
        ((BoolLabel)data).lTrue = genLabel();
        ((BoolLabel)data).lFalse = genLabel();
        ((BoolLabel)data).parent = node.getClass().getName();

        node.jjtGetChild(0).jjtAccept(this, data);
        m_writer.println(first);
        node.jjtGetChild(1).jjtAccept(this, data);
        m_writer.println(String.format("goto %s", ((BoolLabel)data).next));
        m_writer.println(((BoolLabel) data).lTrue);

        ((BoolLabel)data).next = first;
        node.jjtGetChild(3).jjtAccept(this, data);
        node.jjtGetChild(2).jjtAccept(this, data);
        m_writer.println(String.format("goto %s", first));

        return null;
    }

    @Override
    public Object visit(ASTIfStmt node, Object data) {
        ((BoolLabel)data).lTrue = genLabel();

        ((BoolLabel)data).lFalse = (node.jjtGetNumChildren() <= 2) ? ((BoolLabel)data).next : genLabel();;
        node.jjtGetChild(0).jjtAccept(this, data);
        m_writer.println(String.format("%s", ((BoolLabel)data).lTrue));
        node.jjtGetChild(1).jjtAccept(this, data);

        if(node.jjtGetNumChildren() >= 3 ){
            m_writer.println(String.format("goto %s", ((BoolLabel)data).next));
            m_writer.println(String.format("%s", ((BoolLabel)data).lFalse));
            node.jjtGetChild(2).jjtAccept(this, data);
        }
        return null;
    }

    @Override
    public Object visit(ASTWhileStmt node, Object data) {
        String first = genLabel();
        ((BoolLabel)data).lFalse = ((BoolLabel)data).next;
        ((BoolLabel)data).lTrue = genLabel();
        ((BoolLabel)data).next = first;
        m_writer.println(first);

        node.jjtGetChild(0).jjtAccept(this, data);
        m_writer.println(((BoolLabel)data).lTrue);
        node.jjtGetChild(1).jjtAccept(this, data);
        m_writer.println(String.format("goto %s", first));

        return null;
    }


    @Override
    public Object visit(ASTAssignStmt node, Object data) {
        StringBuilder str = new StringBuilder();
        str.append(node.jjtGetChild(1).jjtAccept(this, data));
        String lexeme = (String)(node.jjtGetChild(0)).jjtAccept(this, data);

        if(!str.toString().equals("")){
            m_writer.println(lexeme + " = " + str);
            return null;
        }

        BoolLabel dataForm = (BoolLabel) data;
        m_writer.println(dataForm.lTrue);
        m_writer.println(lexeme + " = 1");
        m_writer.println(String.format("goto %s",dataForm.next));
        m_writer.println(dataForm.lFalse);
        m_writer.println(lexeme + " = 0");

        return null;
    }



    @Override
    public Object visit(ASTExpr node, Object data){
        return node.jjtGetChild(0).jjtAccept(this, data);
    }


    public String codeExtAddMul(SimpleNode node, Object data,
                                Vector<String> ops, List<String> validOps) {
        StringBuilder str = new StringBuilder();
        for(int i = 0; i < node.jjtGetNumChildren(); ++i){
            str.append((String) node.jjtGetChild(i).jjtAccept(this, data));
            if(ops.size() > 0 && i < ops.size() && validOps.contains(ops.get(i))){
                str.append(" ").append(ops.get(i)).append(" ");
            }
        }
        return str.toString();
    }

    @Override
    public Object visit(ASTAddExpr node, Object data) {
        if(node.getOps().size() <= 0){
            return node.jjtGetChild(0).jjtAccept(this, data);
        }
        StringBuilder string = new StringBuilder();
        string.append(genId());
        String id = string.toString();
        ArrayList<String> validOps = new ArrayList<>();
        validOps.add("+");
        validOps.add("-");
        string.append(" = ");
        string.append(codeExtAddMul(node, data, node.getOps(), validOps));
        m_writer.println(string);
        return id;
    }

    @Override
    public Object visit(ASTMulExpr node, Object data) {

        if(node.getOps().size() <= 0){
            return node.jjtGetChild(0).jjtAccept(this, data);
        }

        StringBuilder string = new StringBuilder();
        string.append(genId());
        String id = string.toString();
        ArrayList<String> validOps = new ArrayList<>();
        validOps.add("*");
        validOps.add("/");
        string.append(" = ");
        string.append(codeExtAddMul(node, data, node.getOps(), validOps));
        m_writer.println(string);

        return id;
    }

    @Override
    public Object visit(ASTUnaExpr node, Object data) {
        if(node.getOps().size() <= 0){
            return node.jjtGetChild(0).jjtAccept(this, data);
        }
        String oldVal = "";
        for(int i = 0; i< node.getOps().size(); i++){
            String addrChild = (i<node.jjtGetNumChildren()) ?
                    (String)node.jjtGetChild(0).jjtAccept(this, data) : String.format("%s",oldVal);;
            String id = genId();
            StringBuilder addr = new StringBuilder();
            m_writer.println(addr.append(id)
                            .append(String.format(" = %s ", node.getOps().get(i)))
                            .append(addrChild));
            oldVal = id;
        }
        return oldVal;
    }

    @Override
    public Object visit(ASTBoolExpr node, Object data) {
        if(node.getOps().size() <= 0){
            return node.jjtGetChild(0).jjtAccept(this, data);
        }

        if(node.jjtGetParent().getClass() != ASTBoolExpr.class
                && ((BoolLabel) data).lTrue == null ) {
            ((BoolLabel) data).lTrue = genLabel();
            ((BoolLabel) data).lFalse = genLabel();
        }

        BoolLabel firstData = node.getOps().get(0).equals("&&") ?
                new BoolLabel(genLabel(), ((BoolLabel) data).lFalse) : new BoolLabel(((BoolLabel) data).lTrue, genLabel());
        node.jjtGetChild(0).jjtAccept(this, firstData);
        if(node.getOps().get(0).equals("&&"))
            m_writer.println(firstData.lTrue);
        else
            m_writer.println(firstData.lFalse);

        BoolLabel secondData = new BoolLabel(((BoolLabel) data).lTrue,
                ((BoolLabel) data).lFalse);
        node.jjtGetChild(1).jjtAccept(this, secondData);

        return "";
    }

    @Override
    public Object visit(ASTCompExpr node, Object data) {
        if(node.getValue() == null) return node.jjtGetChild(0).jjtAccept(this, data);

        if(((BoolLabel)data).lTrue == null) ((BoolLabel) data).lTrue = genLabel();
        if(((BoolLabel)data).lFalse == null) ((BoolLabel) data).lFalse = genLabel();

        String firstReturn = (String)node.jjtGetChild(0).jjtAccept(this, data);
        String secondReturn = (String)node.jjtGetChild(1).jjtAccept(this, data);
        m_writer.println(String.format("if %s %s %s goto %s", firstReturn,
                node.getValue(), secondReturn, ((BoolLabel)data).lTrue));

        if(((BoolLabel)data).parent == null){
            m_writer.println(String.format("goto %s", ((BoolLabel)data).lFalse));
        }

        return "";
    }

    @Override
    public Object visit(ASTNotExpr node, Object data) {
        if(node.getOps().size() <= 0) return node.jjtGetChild(0).jjtAccept(this, data);

        if(((BoolLabel)data).lTrue == null){
            ((BoolLabel) data).lTrue = genLabel();
            ((BoolLabel) data).lFalse = genLabel();
        }

        BoolLabel dataVal = (BoolLabel)data;
        BoolLabel interData = new BoolLabel(dataVal.lTrue, dataVal.lFalse);
        BoolLabel newData = new BoolLabel();

        for(int i = 0; i< node.getOps().size(); i++){
            newData.lTrue = interData.lFalse;
            newData.lFalse = interData.lTrue;
            interData = new BoolLabel(newData.lTrue, newData.lFalse);
        }
        node.jjtGetChild(0).jjtAccept(this, newData);
        return "";
    }

    @Override
    public Object visit(ASTGenValue node, Object data) {
        return node.jjtGetChild(0).jjtAccept(this, data);
    }

    @Override
    public Object visit(ASTBoolValue node, Object data) {
        if(((BoolLabel)data).lTrue == null){
            ((BoolLabel) data).lTrue = genLabel();
            ((BoolLabel) data).lFalse = genLabel();
        }
        m_writer.println(node.getValue() ?
                String.format("goto %s",((BoolLabel)data).lTrue) : String.format("goto %s",((BoolLabel)data).lFalse));
        return "";
    }


    @Override
    public Object visit(ASTIdentifier node, Object data) {
        if(node.jjtGetParent().getClass() == ASTAssignStmt.class
                || SymbolTable.get(node.getValue()) != VarType.Bool) return node.getValue();

        if(((BoolLabel)data).lTrue == null){
            ((BoolLabel) data).lTrue = genLabel();
            ((BoolLabel) data).lFalse = genLabel();
        }

        BoolLabel dataVal = (BoolLabel)data;
        m_writer.println(String.format("if %s == 1 goto %s", node.getValue(),
                dataVal.lTrue));
        m_writer.println(String.format("goto %s", dataVal.lFalse));
        return "";
    }

    @Override
    public Object visit(ASTIntValue node, Object data) {
        return String.format("%d", node.getValue());
    }


    @Override
    public Object visit(ASTSwitchStmt node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, data);
        }
        return null;
    }

    @Override
    public Object visit(ASTCaseStmt node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, data);
        }
        return null;
    }

    @Override
    public Object visit(ASTDefaultStmt node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, data);
        }
        return null;
    }

    public enum VarType {
        Bool,
        Number
    }

    private static class BoolLabel {
        public String lTrue = null;
        public String lFalse = null;
        public String parent;
        public String next;

        public BoolLabel(String t, String f) {
            lTrue = t;
            lFalse = f;
        }

        public BoolLabel(){}
    }


}
